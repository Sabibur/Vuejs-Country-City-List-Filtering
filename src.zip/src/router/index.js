// import Vue from 'vue'
// import Router from 'vue-router'
// import filterdetails from '@/components/filterdetails'

// // Vue.use(Router)

// export default new Router({
//   routes: [
//     {
//       path: '/',
//       name: 'filterdetails',
//       component: filterdetails
//     }
//   ]
// })
